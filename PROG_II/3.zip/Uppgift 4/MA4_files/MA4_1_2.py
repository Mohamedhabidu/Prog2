
"""
Solutions to module 4
Review date:
"""

student = "Erica Brun"
reviewer = ""

import math as m
import random as r
import functools

def sphere_volume(n, d):
    # n is a list of set of coordinates
    # d is the number of dimensions of the sphere 
    radius = 1
    points_in = 0
    for _ in range(n):
        x_ran = [r.uniform(-1,1) for _ in range (d)]                # List comprehension
        x_ran_sq = list(map(lambda x : x**2, x_ran))                # Map and lambda function
        summa = functools.reduce(lambda x, y : x+y, x_ran_sq)       # Functools.reduce for sum
        if summa <= 1:
             points_in += 1
    return (2**d)*points_in/n

def hypersphere_exact(n,d):
    return (m.pi**(d/2)) / m.gamma(d/2 + 1)
     
def main():
    n = 100000
    d = 2
    sphere_volume(n,d)


if __name__ == '__main__':
	main()
