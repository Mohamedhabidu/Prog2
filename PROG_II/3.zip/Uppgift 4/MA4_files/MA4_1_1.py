
"""
Solutions to module 4
Review date:
"""

student = "Erica Brun"
reviewer = ""

import math
import random as r
import matplotlib.pyplot as plt 

def approximate_pi(n):
    # Write your code here
    radie = 1
    nc = 0
    x_in, y_in, x_out, y_out = [], [], [], []
    for _ in range(n):
        x = r.uniform(-1, 1)
        y = r.uniform(-1, 1)
        if x**2 + y**2 <= radie:
             nc += 1
             x_in.append(x)
             y_in.append(y)
        elif x**2 + y**2 > radie:
             x_out.append(x)
             y_out.append(y)
    pi = 4*nc/n
    print(f'----------------------------- \n'
          f'Number of points, nc: {nc} \n'
          f'Approximation of PI: {pi} \n'
          f'Built in constant PI: {math.pi} \n'
          f'-----------------------------')
    plt.figure(figsize=(7,7))
    plt.plot(x_in, y_in, 'ro', label = 'Points inside circle')
    plt.plot(x_out, y_out, 'bo', label = 'Points outside circle')
    plt.title(f'n = {n}')
    plt.legend(loc = 'upper right')
    plt.show()
    return pi



    
def main():
    dots = [1000, 10000, 100000]
    for n in dots:
        approximate_pi(n)

if __name__ == '__main__':
	main()
