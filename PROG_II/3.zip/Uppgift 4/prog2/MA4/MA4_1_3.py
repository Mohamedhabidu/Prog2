
"""
Solutions to module 4
Review date:
"""

student = "Erica Brun"
reviewer = ""

import math as m
import random as r
import functools
from time import perf_counter as pc
import multiprocessing as mp
import concurrent.futures as future

def sphere_volume(n, d):
    # n is a list of set of coordinates
    # d is the number of dimensions of the sphere 
    radius = 1
    points_in = 0
    for _ in range(n):
        x_ran = [r.uniform(-1,1) for _ in range (d)]                # List comprehension
        x_ran_sq = list(map(lambda x : x**2, x_ran))                # Map and lambda function
        summa = functools.reduce(lambda x, y : x+y, x_ran_sq)       # Functools.reduce for sum
        if summa <= 1:
             points_in += 1
    return (2**d)*points_in/n

def hypersphere_exact(n,d):
    return (m.pi**(d/2)) / m.gamma(d/2 + 1)

# parallel code - parallelize for loop
def sphere_volume_parallel1(n,d,np):
     #using multiprocessor to perform 10 iterations of volume function
    def sphere_volume_q(n, d, q):
        result = sphere_volume(n, d)
        q.put(result)
    start = pc()
    processes = []
    q = mp.Queue()
    for _ in range(10):
         p = mp.Process(target=sphere_volume_q, args=[n, d, q])
         processes.append(p)
    for p in processes:
         p.start()
    for p in processes:
         p.join()
    results = [q.get() for _ in range(10)]
    result = sum(results)/np
    end = pc()
    print(f"Process took {round(end-start, 2)} seconds")
    return result

# parallel code - parallelize actual computations by splitting data
def sphere_volume_parallel2(n,d,np):
    start = pc()
    with future.ProcessPoolExecutor() as ex:
        processes = list(ex.map(sphere_volume, [n // np for _ in range(np)], [d for _ in range(np)]))
    result = sum(processes)/np
    end = pc()
    print(f'Execution time:  {round(end-start, 2)}s')
    return result

def main():
    # part 1 -- parallelization of a for loop among 10 processes 
    n = 100000
    d = 11

    for y in range (10):
        sphere_volume(n,d)


if __name__ == '__main__':
	main()
