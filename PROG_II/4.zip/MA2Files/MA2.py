"""
Solutions to module 2 - A calculator
Student: Erica Brun
Mail: erica.brun.9692@student.uu.se
Reviewed by: David Bagstevold
Reviewed date:30/9-2024
"""

"""
Note:
The program is only working for a very tiny set of operations.
You have to add and/or modify code in ALL functions as well as add some new functions.
Use the syntax charts when you write the functions!
However, the class SyntaxError is complete as well as handling in main
of SyntaxError and TokenError.
"""

import math
from tokenize import TokenError  
from MA2tokenizer import TokenizeWrapper


class SyntaxError(Exception):
    def __init__(self, arg):
        self.arg = arg
        super().__init__(self.arg)

class EvaluationError(Exception):
    def __init__(self, arg):
        self.arg = arg
        super().__init__(self.arg)

def log(x):
    if x>0:
        return math.log(x)
    else:
        raise EvaluationError('The argument for log must be larger than 0')

# def fac(n):
#     if n==0:
#         return 1
#     elif n<0:
#         raise EvaluationError('Argument for fac must be larger than 0')
#     elif n.is_integer() is False:
#         raise EvaluationError('Argument for fac must be an integer')
#     else:
#         return int(n*fac(n-1))

def fac(n):
    if n.is_integer() is False:
        raise EvaluationError('Argument for fac must be an integer')
    elif n==0:
        return 1
    elif n<0:
        raise EvaluationError('Argument for fac must be larger than 0')
    else:
        return int(n*fac(n-1))
    
    
def fib(n):
    if n.is_integer():
        memory = {0:0, 1:1}
        def _fib(n):
            if n not in memory:
                memory[n] = _fib(n-1) + _fib(n-2)
            return memory[n]
        return _fib(n)
    else:
        raise EvaluationError('Argument for fib must be an integer')
    
def sum(arglist):
    summa = 0
    for n in arglist:
        summa+=n
    return summa

def mean(arglist):
    return sum(arglist)/len(arglist)


function_1 = {'sin': math.sin, 'cos': math.cos, 'exp': math.exp, 'log': log, 'fib': fib, 'fac': fac, 'abs': abs}
function_n = {'max': max, 'min': min, 'mean': mean, 'sum': sum}


def arglist(wtok, variables):
    arg_lst = []
    if wtok.get_current() == '(':
        wtok.next()
        arg_lst.append(assignment(wtok, variables))
        while wtok.get_current() == ',':
            wtok.next()
            arg_lst.append(assignment(wtok, variables))
        if wtok.get_current() == ')':
            wtok.next()
            return arg_lst
        else:
            raise SyntaxError("Expecteda ',' or ')'")
    else:
        raise SyntaxError("Expected a '(' after function")


def statement(wtok, variables):
    """ See syntax chart for statement"""
    if wtok.is_at_end():
        return
    else:
        result = assignment(wtok, variables)
        if wtok.is_at_end():
            return result
        else:
            raise SyntaxError("Expected end of line (EOL)")

# def statement(wtok, variables):
#     """ See syntax chart for statement"""
#     result = assignment(wtok, variables)
#     return result


def assignment(wtok, variables):
    """ See syntax chart for assignment"""
    result = expression(wtok, variables)
    while wtok.get_current() == '=':
        wtok.next()
        if wtok.is_name():
            variables[wtok.get_current()] = result
            wtok.next()
            if wtok.is_at_end():
                return result
            elif not wtok.get_current() in ('=',')'):
                raise SyntaxError("Expected paranthasis, further assignment of variables or end of line after assignment of variable")
        else:
            raise SyntaxError("Expected variable name after '='")
    return result


def expression(wtok, variables):
    """ See syntax chart for expression"""
    result = term(wtok, variables)
    while wtok.get_current() in ('+', '-'):
        if wtok.get_current() == '+':
            wtok.next()
            result = result + term(wtok, variables)
        elif wtok.get_current() == '-':
            wtok.next()
            result = result - term(wtok, variables)
    return result


def term(wtok, variables):
    """ See syntax chart for term"""
    result = factor(wtok, variables)
    while wtok.get_current() in ('*', '/'): 
        if wtok.get_current() == '*':
            wtok.next()
            result = result * factor(wtok, variables)
        elif wtok.get_current() == '/':
            wtok.next()
            denominator = factor(wtok, variables)
            if denominator != 0:
                result = result / denominator
            elif denominator == 0:
                raise EvaluationError('Error. Division by zero.')
    return result


def factor(wtok, variables):
    """ See syntax chart for factor"""
    var = variables.get(wtok.get_current())

    if wtok.get_current() == '(':
        wtok.next()
        result = assignment(wtok, variables)
        if wtok.get_current() != ')':
            raise SyntaxError("Expected ')'")
        else:
            wtok.next()
            
    elif wtok.is_number():
        result = float(wtok.get_current())
        wtok.next()

    elif wtok.get_current() == '-':               
        wtok.next()
        return -factor(wtok, variables)
    
    elif wtok.get_current() in function_1.keys():
        key = wtok.get_current()
        wtok.next()
        if wtok.get_current() == '(':
            wtok.next()
            argument = assignment(wtok, variables)
            if wtok.get_current() == ')':
                result = function_1[key](argument)
                wtok.next()
                return result
            else:
                raise SyntaxError("Expeced a ')'")
        else:
            raise SyntaxError("Expected a '('")
        
    elif wtok.get_current() in function_n.keys():
        key = wtok.get_current()
        wtok.next()
        result = function_n[key](arglist(wtok, variables))
        return result
    
    elif wtok.is_name():
        if var != None:
            result = float(var)
            wtok.next()
        else:
            raise EvaluationError(f'Undefined variable: {wtok.get_current()}')

    else:
        raise SyntaxError("Expected number, name, function, a minus sign or '('")  
    return result


         
def main():
    """
    Handles:
       the iteration over input lines,
       commands like 'quit' and 'vars' and
       raised exceptions.
    Starts with reading the init file
    """
    
    print("Numerical calculator")
    variables = {"ans": 0.0, "E": math.e, "PI": math.pi}
    # Note: The unit test file initiate variables in this way. If your implementation 
    # requires another initiation you have to update the test file accordingly.
    init_file = 'MA2init.txt'
    lines_from_file = ''
    try:
        with open(init_file, 'r') as file:
            lines_from_file = file.readlines()
    except FileNotFoundError:
        pass

    while True:
        if lines_from_file:
            line = lines_from_file.pop(0).strip()
            print('init  :', line)
        else:
            line = input('\nInput : ')
        if line == '' or line[0]=='#':
            continue
        wtok = TokenizeWrapper(line)

        if wtok.get_current() == 'quit':
            print('Bye')
            exit()
        elif wtok.get_current() == 'vars':                    # If input is 'vars' then
            for var in variables:                             # for every key in variables
                print(f'{var} : {variables[var]}')            # print key and its value
        else:
            try:
                result = statement(wtok, variables)
                variables['ans'] = result
                print('Result:', result)

            except SyntaxError as se:
                print("*** Syntax error: ", se)
                print(
                f"Error occurred at '{wtok.get_current()}' just after '{wtok.get_previous()}'")

            except EvaluationError as ee:
                print("*** Evaluation error: ", ee)

            except TokenError as te:
                print('*** Syntax error: Unbalanced parentheses')
 


if __name__ == "__main__":
    main()
